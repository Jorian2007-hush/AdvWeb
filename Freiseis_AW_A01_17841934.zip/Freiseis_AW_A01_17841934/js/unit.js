"use strict";

console.log("Hello world");

do {
    let inches = parseFloat(prompt("Enter your inches:\n or enter 999 to quit.", 999));

    if (inches == 999) break;

    if (Number.isNaN(inches)) {
        alert("Please enter a real number");
        continue;
    }

    const cm = (inches * 2.54).toFixed(2);

    document.write(`${inches} inches = ${cm} centimeters <br>`);

} while (true);

document.write(`<br><p style='text-indent:25px;'>Have a nice day!</p>`);